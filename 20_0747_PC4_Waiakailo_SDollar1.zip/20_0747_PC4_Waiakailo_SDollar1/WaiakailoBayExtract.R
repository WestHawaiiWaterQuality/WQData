# WaiakailoBay/Kohala EIS with water values in Table2, 
# RStudio 1.0.153 "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_12_6) AppleWebKit/604.5.6 (KHTML, like Gecko)"
# +Install pdftools Package v1.5 "Text Extraction and Converting of PDF Documents"
pdf_file <- "~/Dropbox/WestHawaiiWaterQuality/Data/20_0747_WaiakailoBayKohala_EIS/2015-07-08-HA-DEA-Kohala-Shoreline-LLC-Project.pdf"
# pull in PDF
text <- pdf_text(pdf_file)
# parse file for table2
chemData <- grep("TABLE 2. Water chemistry", text) # three transects in ug/L
cat(text[chemData])
# write to text file with separators
write.table(text[chemData], "~/Dropbox/WestHawaiiWaterQuality/Data/20_0747_WaiakailoBayKohala_EIS/2015-07-08-HA-DEA-Kohala-Shoreline-LLC-ProjectTable2ChemData3.txt",  sep=",")

