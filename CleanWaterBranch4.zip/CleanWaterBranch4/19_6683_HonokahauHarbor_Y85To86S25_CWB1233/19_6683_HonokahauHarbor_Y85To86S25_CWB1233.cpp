Dataset {
  Sequence {
    Float64 time;
    Float32 longitude;
    Float32 latitude;
    Int32 location_id;
    String location_name;
    Float32 number_concentration_of_enterococcus_in_sea_water;
    Float32 number_concentration_of_clostridium_perfringens_in_sea_water;
    Int32 sea_water_quality_alert;
    Float32 sea_water_temperature;
    Float32 sea_water_salinity;
    Float32 sea_water_turbidity;
    Float32 sea_water_ph_reported_on_total_scale;
    Float32 mass_concentration_of_oxygen_in_sea_water;
    Float32 fractional_saturation_of_oxygen_in_sea_water;
  } s;
} s;
---------------------------------------------
  s.time, s.longitude, s.latitude, s.location_id, s.location_name, s.number_concentration_of_enterococcus_in_sea_water, s.number_concentration_of_clostridium_perfringens_in_sea_water, s.sea_water_quality_alert, s.sea_water_temperature, s.sea_water_salinity, s.sea_water_turbidity, s.sea_water_ph_reported_on_total_scale, s.mass_concentration_of_oxygen_in_sea_water, s.fractional_saturation_of_oxygen_in_sea_water
  4.993587E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 26.7, 34.4, 0.1, 8.2, 6.6, 
  4.99359E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 26.2, 35.0, 0.3, 8.2, 6.3, 
  4.993593E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 26.0, 35.1, 0.4, 8.2, 6.3, 
  5.030046E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 24.2, 32.9, 0.1, 8.1, 6.1, 
  5.0300538E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 21.0, 34.3, 0.4, 8.1, 5.5, 
  5.0300604E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 24.2, 34.4, 0.9, 8.1, 5.2, 
  5.072373E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 24.5, 33.3, 0.1, 8.2, 6.7, 
  5.072376E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 24.6, 34.1, 0.5, 8.2, 6.8, 
  5.072379E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 24.6, 34.2, 1.0, 8.2, 6.8, 
  5.084541E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 25.1, 34.2, 1.0, 8.1, 6.8, 
  5.084544E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 25.1, 34.0, 0.6, 8.2, 6.8, 
  5.084547E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 25.1, 33.9, 0.2, 8.1, 7.0, 
  5.151084E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 25.7, 32.0, 0.2, , 7.4, 
  5.151087E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 25.4, 33.7, 0.5, , 6.8, 
  5.15109E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 25.2, 33.7, 0.5, , 6.7, 
  5.163108E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 25.5, 32.3, 0.1, 8.2, 6.6, 
  5.229597E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 26.5, 33.4, 0.1, 8.2, 6.5, 
  5.2296E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 26.7, 33.8, 0.1, 8.2, 6.6, 
  5.229603E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 26.7, 34.0, 0.2, 8.3, 6.8, 
  5.253951E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 27.5, 33.0, 0.1, 8.2, 7.0, 
  5.253954E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 27.3, 33.9, 0.1, 8.0, 6.5, 
  5.253957E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 26.9, 33.9, 0.3, 8.1, 6.8, 
  5.272047E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 28.0, 33.2, 0.3, 8.2, 6.0, 
  5.27205E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 27.5, 33.2, 0.3, 8.1, 6.2, 
  5.272053E8, -156.03027, 19.675278, 1233, "HONOKAHAU BOAT HARBOR (EMBAYMENT)", , , , 27.4, 33.6, 0.1, 8.1, 6.4, 