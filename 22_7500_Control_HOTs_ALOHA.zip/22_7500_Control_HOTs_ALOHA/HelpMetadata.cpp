http://hahana.soest.hawaii.edu/hot/hot-dogs/whatsnew.html
  
HOT-DOGS 
Hawaii Ocean Time-series Data Organization & Graphical System	

» Home » HOT-DOGS
What's New (and Updated)
6/23/16	Extraction modules have the ability to output data as a netCDF (.NC) file.
5/12/16	Most modules have the ability to adjust certain figure attributes. Select Modify on the left-side of the Menubar to activate/deactivate.
10/23/15	New Absorption Spectra (PUR) Display module added.
8/22/12	New Laser In-Situ Scattering & Transmissometry Display module added.
10/24/11	New Chlorofluorocarbon & Sulfur Hexafluoride Display module added.
9/29/10	New Hyperspectral (Ir)radiance Display module added.
3/18/10	Underway Measurements Display module now plots Potential Density data.
2/3/09	New modules for Epi-Fluorescence Microscopy data added.
1/18/07	Underway Measurements Display module now plots Thermosalinograph data.
11/30/06	New Cruise Summary module (under menu item Miscellaneous) used to plot cruise tracks and cast locations.
11/3/06	Standard Depths modules are now capable of computing averages at not only pressure intervals, but also potential temperature and density intervals. The menu name 
has been appropriately renamed to Standard Intervals.
5/10/06	New Fast Repetition Rate Fluorometry Display module used to plot data collected using a Chelsea FASTtracka Dynamic Photosynthetic Fluorometer.
3/28/06	Two new modules, CTD Extraction and CTD Contour, added.
3/22/06	Links to Metadata added to the help system.
7/8/05	New Inherent Optical Properties Display module (under menu item Vertical Profiles/Display) used to plot absorption and beam attenuation collected using a 
WetLabs AC-9.
4/25/05	Ability to group by Mixed-layer Depth added to Bottle, HPLC Pigment & User Defined Time-series modules.
4/20/05	New option, 'Show Grouping' added to all time-series modules. This option is used to show how the data is grouped together without actually averaging it. It 
will only make a difference if text data is being outputted.
3/16/05	New TSRB (Ir)radiance Display module (under menu item Vertical Profiles/Display) used to plot upwelling radiance & downwelling irradiance collected using a 
Tethered Spectral Radiometer Buoy.
1/12/05	All modules now able to output Postscript plots.
10/7/04	PRR (Ir)radiance Display module now able to plot % Downwelling Irradiance (Ed/Es), % Upwelling radiance (Lu/Es) and % Reflectance (Lu/Ed).
9/2/04	New PRR (Ir)radiance Time-series module (under menu item Horizontal Profiles/Time-series) used to plot monthly/yearly light levels.
8/4/04	New PRR (Ir)radiance Display module (under menu item Vertical Profiles/Display) used to plot upwelling radiance & downwelling irradiance collected using a
 Profiling Reflectance Radiometer.
4/13/04	New Contour modules (under menu item Horizontal Profiles).
4/5/04	Switched from a frame based selection system to a Menu Bar. Display and Standard Depths modules have been put under menu item Vertical Profiles, Time-series 
modules have been put under menu item Horizontal Profiles.
3/16/04	New Mixed-layer Depth module (under menu item Miscellaneous) used to locate thermoclines, picnoclines & nutriclines.
3/9/04	CTD Display now capable of plotting a range of casts as either overlapping lines or as a stagger plot.
3/8/04	Now uses external JavaScript.
Home	About Us	Cruise
  Request	Data	Cruise
  Schedule	Contact Us	Login
  Funding provided by the National Science Foundation (NSF)