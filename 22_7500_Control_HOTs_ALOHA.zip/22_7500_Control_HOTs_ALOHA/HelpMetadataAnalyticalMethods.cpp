http://hahana.soest.hawaii.edu/hot/protocols/protocols.html#
  

TIME-SERIES SAMPLING STRATEGY
  SUMMARY: Our primary objective is to assess variability in biogeochemical fluxes in the North Pacific Subtropical Gyre.
   The sampling program at the time-series station is therefore designed to monitor parameters relevant to biogeochemical cycling in this environment, 
   on three time scales; days, months and years.
  
  1. Time Scales of Variability
    HOT cruises are conducted at approximately monthly intervals, and approximately 72 hours is spent on station. During this period, nearly continuous measurements
     of water column physical characteristics are made using a CTD. One CTD cast is made to 4700 m (maximum water depth is approximately 4750 m), and then 1000 m
      casts are made at approximately 3-hour intervals for at least 36 hours (see Chapter 4). Chemical constituents and relevant biogeochemical cycling rates are
       measured from water samples at discrete depths. In addition, particle flux and primary production are also measured.
    
    This sampling strategy is designed to allow us to assess variability on three time scales. These time scales are approximately on the order of days, months and years. The repeated CTD casts made each month allow us to calculate an average density profile from which variability on tidal and near-inertial time scales has been removed. These average density profiles are useful for the comparison of dynamic height at monthly intervals. In addition, the average density profiles are useful for the comparison of the depth distribution of chemical parameters at monthly intervals. For example, by fitting the distribution of inorganic nutrients to this average density structure, the depth of the nutricline can be defined each month, independent of monthly changes in the density structure of the upper water column and independent of short-term tidal and near-inertial oscillations.
    
    2. Sampling Locations
      Samples are taken at two locations each month. Our primary sampling site is centered at 22° 45'N, 158° 00'W. This location, designated Station ALOHA, is
       approximately 100 km due north of Kahuku Point, Oahu (see map in Chapter 1). The station is defined as within a 6 mi radius of the center. This location is
        believed to be free of significant biogeochemical island mass effects; it is located 50 km (one Rossby radius) away from the topography associated with the
         Hawaiian Ridge, it is northeast (upwind) of the Hawaiian Archipelago, and it is above flat topography in 4750 m of water. Samples are also routinely collected 
         at a station W-SW of the island of Oahu, approximately 10 km off Kahe Point. The station coordinates are 21° 20.6'N, 158° 16.4'W. Water depth at this
          location is approximately 1500 m. This station serves as a coastal analogue to our deep water station and the data collected at this location will provide 
          a near-shore time-series.
      
      3. Sampling: High-Resolution Profiles
        3.1.	XBT Transect: Each month as we transit between Station KAHE and Station ALOHA (see map in Chapter 1) we deploy XBTs at 7 nmi spacing in order to record
         the onshore-to-offshore gradients in temperature. The XBT data are logged on a computer.
      3.2.	CTD: Profiles of relevant physical, chemical and biological oceanic properties are collected using a Seabird CTD (see Chapter 4). The CTD is equipped with
       external temperature, conductivity, dissolved oxygen and fluorescence sensors and with an internal pressure sensor. A General Oceanics 24-place pylon and deck box are used to obtain water samples from discrete depths using 12-liter Niskin bottles on a Scripps- type aluminum rosette frame (see Chapter 2, section 4).
      3.3.	ADCP: When using the R/V Moana Wave (or equivalently equipped research vessel), we routinely record upper water column currents using a hull-mounted acoustic
       doppler current profiler (ADCP).
      4. Sampling: Discrete Depth Measurements
        4.1.	Our sampling strategy is based, to the extent possible, on resolving depth profiles of specific chemical constituents from contiguous casts. This is done
         in order to produce profiles which minimize the effects of time-dependent density structure variation within the water column.
      4.2.	Sampling depths range from the surface to approximately 50 m above the seafloor (4750 m), with most of the samples being collected in the upper 1000 m. 
      Approximately 20% of the samples are collected and analyzed in triplicate. To the extent possible, samples are collected from the same depths and/or density 
      levels each month in order to facilitate comparisons between monthly profiles. Salinity samples are collected from all Niskin bottles in order to identify bottle trip errors.
      4.3.	Depths for GOFS and WOCE hydrographic sampling at Station KAHE and Station ALOHA are shown in Tables 1-4. GOFS-related chemical sampling is concentrated 
      in the upper 1000 m. WOCE hydrographic sampling is conducted from the surface to approximately 50 m above the seafloor. The WOCE program collects samples for
       inorganic nutrients, oxygen and salinity at 200 m intervals from the seafloor to 2000 m, at 150 m intervals from 2000 to 1100 m, and at 23 potential density 
       horizons between 1000 m and the surface.
      5. Flux Measurements
        5.1.	The rate of primary production is measured using 14C trace- metal free methods. Incubations are conducted both on deck and in situ (see Chapter 14).
      5.2.	Particle fluxes are measured using free-drifting sediment traps (see Chapter 18).
      
      
      
      
      Table 1
      WOCE/GOFS Hydrographic Sampling at Station ALOHA1
        
        ___________________________________________________________________________
      CAST #1                          CAST #2
      
      Depth2  Oxygen  Nutrients  Salinity     Depth  DIC3 Oxygen Nutrients Salinity
        (m)                                     (m)
        ___________________________________________________________________________
      
      2      1         1         1          800           1       1        1
      26      1         1         1          900           1       1        1
      50      1         1         1         1000     1     1       1        1
      75      1         1         1         1100           1       1        1
      100      1         1         1         1250           1       1        1
      125      1         1         1         1400           1       1        1
      150      1         1         1         1550           1       1        1
      175      1         1         1         1700           1       1        1
      225      1         1         1         1850           1       1        1
      300      1         1         1         2000     1     1       1        1
      325      1         1         1         2200           1       1        1
      400      1         1         1         2400           1       1        1
      450      1         1         1         2600           1       1        1
      475      1         1         1         2800           1       1        1
      500      1         1         1         3000     3     3       3        1
      550      1         1         1         3200           1       1        1
      600      1         1         1         3400           1       1        1
      650      1         1         1         3600           1       1        1
      725      1         1         1         3800           1       1        1
      800      1         1         1         4000           1       1        1
      900      1         1         1         4200           1       1        1
      975      1         1         1         4400     1     1       1        1
      1020      1         1         1         4525           1       1        1
      ___________________________________________________________________________
      
      1 Numbers within table represent number of replicates
        2 Actual depths vary from cruise to cruise and are dependent upon density 
        structure of water column and presence of interesting features
        3 Dissolved inorganic carbon 
        
        
        
        Table 2
      GOFS Hydrographic Sampling at Station ALOHA1
        
        ________________________________________________________________________
      
      Depth DIC2 Nutrients Oxygen Chl a Salinity    Low Level       Low Level
        (m)                                       Nitrate/Nitrite3  Phosphorus4
        ________________________________________________________________________
      5   3       1       3      1      1            2              1
      25   3       1       1      1      1            2              1
      35           1       1      1      1            2              1
      45   1       1       1      1      3            2              1
      60   1       1       1      3      1            2              1
      75   1       1       1      1      1            2              1
      85           1       1      1      1            2              1
      95   1       3       3      3      1            2              1
      105           1       1      1      3            2              1
      115   3       1       1      1      1            2              1
      125           1       1      3      1            2              1
      135           1       1      1      1            2              1
      150   1       1       1      1      1            2              1
      160                   1      1      1                                           
      175   1       1       1      1      1            2              1
      185                   1             1                                           
      200   1       3       1      1      1                           
      210                   1             1                           
      225   3       1       1             1                           
      235                   1             1                           
      250   1       1       3             3                           
      275           1       1             1                           
      300   1       1       1             1                           
      325           1       1             1                           
      350           1       1             1                           
      400   3       1       1             1                           
      500   1       1       3             1                           
      600   1       1       1             1                           
      700           1       1             1                           
      800   1       3       1             1                           
      900           1       1             1                           
      1000   3       1       3             3                           
      ________________________________________________________________________
      
      1 Numbers within table represent the number of replicates
        2 Dissolved inorganic carbon 
        3 Nitrate and nitrite measured with nitrogen oxides analyzer 
        4 Phosphorus measured with magnesium hydroxide co-precipitation method
        
        
        
        Table 3
      GOFS Biological Sampling at Station ALOHA1 
        
        _____________________________________________________________
      Depth Particulate2 Bacteria Chl a Pigments3 ATP   Primary
        (m)     C/N/P     and LPS                      Production4
        _____________________________________________________________
      5       1          1        1      1      3     OD/IS
        25       1          1        1      1      3     OD/IS
        45       1          1        1      1      3     OD/IS
        75       1          1        1      1      3     OD/IS
        100       1          1        3      1      3     OD/IS
        125       1          1        3      1      3     OD/IS
        150       1          1        1      1      3     OD/IS
        175       1          1        1      1      3     OD/IS
        250       1          1                      3     
      500       1          1                      3     
      750       1          1                      3     
      1000       1          1                      3     
      _____________________________________________________________
      
      1 Numbers in table represent the number of replicates
        2 Occasional replicates taken
        3 HPLC analysis of plant pigments
        4 OD represents on-deck incubations; IS represents in situ 
          incubations
          
          
          
          Table 4
        WOCE/GOFS Hydrographic and Biological Sampling at Station KAHE1
          
          _______________________________________________________________
        Depth  Nutrients  Oxygen  Chl a  Salinity2     Low level
          (m)                                        Nitrate/Nitrite3
          _______________________________________________________________
        5       1         1      1        1             2
        25       1         1      1        1             2
        45       1         1      1        1             2
        60       1         1      3        1             2
        75       1         1      1        1             2
        95       3         3      3        1             2
        105       1         1      1        1             2
        115       1         1      1        1             2
        125       1         1      3        1             2
        150       1         1      1        1             2
        175       1         1      1        1             2
        200       1         1      1        1             2
        225       1         1               1                  
        250       1         3               1                  
        300       1         1               1                  
        400       1         1               1                  
        500       1         1               1                  
        750       1         1               1                  
        1000       1         1               1                  
        _______________________________________________________________
        
        1 Numbers within table represent the number of replicates
          2 Occasional replicates taken
          3 Nitrate and nitrite measured with nitrogen oxides analyzer