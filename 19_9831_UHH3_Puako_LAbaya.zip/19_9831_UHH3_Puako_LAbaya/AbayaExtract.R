# LAbaya Journal Masters' Thesis with water values
pdf_file <- "~/Dropbox/WestHawaiiWaterQuality/Data/19_9831_Puako_LAbaya_YNov14ToJul15LowTideSunrise_S16Stations/19_9831_LAbaya_Puako_Y2014_JRL.pdf"

# pull in PDF using 'pdftools' pkg, check package is installed
text <- pdf_text(pdf_file)

bioData <- grep("Table 1", text) # Enteroccocci and Clostridium data we need
cat(text[bioData])
chemData <- grep("Table 3", text) # Chemistry data we need
cat(text[chemData])

# save bitmap image too
bitmap <- pdf_render_page(pdf_file, page = 4)
png::writePNG(bitmap, "Appendix A-T1-S1-1.png")

write.table(text[chemData], "~/Dropbox/WestHawaiiWaterQuality/Data/19_9831_Puako_LAbaya_YNov14ToJul15LowTideSunrise_S16Stations/19_9831_LAbaya_Puako_Y2014_JRL_Table3ChemistryData.txt", sep="\t")
write.table(text[bioData],  "~/Dropbox/WestHawaiiWaterQuality/Data/19_9831_Puako_LAbaya_YNov14ToJul15LowTideSunrise_S16Stations/19_9831_LAbaya_Puako_Y2014_JRL_Table1BiologicData.txt",  sep="\t")

