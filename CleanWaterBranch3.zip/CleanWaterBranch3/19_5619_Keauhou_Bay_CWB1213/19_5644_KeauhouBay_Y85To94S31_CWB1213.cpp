Dataset {
  Sequence {
    Float64 time;
    Float32 longitude;
    Float32 latitude;
    Int32 location_id;
    String location_name;
    Float32 number_concentration_of_enterococcus_in_sea_water;
    Float32 number_concentration_of_clostridium_perfringens_in_sea_water;
    Int32 sea_water_quality_alert;
    Float32 sea_water_temperature;
    Float32 sea_water_salinity;
    Float32 sea_water_turbidity;
    Float32 sea_water_ph_reported_on_total_scale;
    Float32 mass_concentration_of_oxygen_in_sea_water;
    Float32 fractional_saturation_of_oxygen_in_sea_water;
  } s;
} s;
---------------------------------------------
  s.time, s.longitude, s.latitude, s.location_id, s.location_name, s.number_concentration_of_enterococcus_in_sea_water, s.number_concentration_of_clostridium_perfringens_in_sea_water, s.sea_water_quality_alert, s.sea_water_temperature, s.sea_water_salinity, s.sea_water_turbidity, s.sea_water_ph_reported_on_total_scale, s.mass_concentration_of_oxygen_in_sea_water, s.fractional_saturation_of_oxygen_in_sea_water
  4.993965E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 26.3, 34.6, 0.1, 8.1, 6.4, 
  4.993968E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 26.2, 34.9, 0.4, 8.1, 6.3, 
  4.993971E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 26.0, 34.9, 0.5, 8.1, 6.2, 
  5.029971E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 24.3, 34.2, 0.5, 8.1, 6.2, 
  5.029977E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 24.3, 34.2, 0.3, 8.1, 6.1, 
  5.029983E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 24.2, 33.9, 0.1, 8.0, 6.0, 
  5.072505E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 25.4, 34.1, 0.1, 8.2, 6.5, 
  5.072508E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 25.1, 34.3, 0.7, 8.2, 6.6, 
  5.072511E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 25.0, 34.3, 0.5, 8.2, 6.6, 
  5.084586E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 25.0, 34.4, 0.8, 8.1, 7.0, 
  5.084589E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 25.0, 34.3, 0.9, 8.1, 6.9, 
  5.084592E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 25.2, 34.2, 0.5, 8.1, 6.8, 
  5.151132E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 26.4, 33.7, 0.2, , 6.7, 
  5.151135E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 25.8, 33.9, 0.2, , 6.6, 
  5.151138E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 25.3, 33.9, 0.4, , 6.6, 
  5.163237E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 26.9, 33.2, 0.1, 8.2, 7.1, 
  5.229669E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 27.5, 33.8, 0.1, 8.2, 6.2, 
  5.229672E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 26.9, 34.0, 0.2, 8.2, 6.3, 
  5.229675E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 26.8, 33.9, 0.6, 8.2, 6.6, 
  5.253822E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 27.5, 33.6, 0.1, , 5.9, 
  5.253828E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 27.4, 33.9, 0.4, , 6.5, 
  5.253831E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 27.3, 33.7, 0.3, , 6.6, 
  5.271993E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 27.7, 33.0, 0.2, 8.1, 5.8, 
  5.271996E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 27.6, 33.6, 0.4, 8.2, 6.0, 
  5.271999E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 27.6, 33.4, 0.2, 8.1, 6.2, 
  7.736895E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 26.3, 34.3, 0.2, 8.2, 5.1, 
  7.736904E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 26.2, 34.6, 0.2, 8.2, 5.1, 
  7.736913E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 25.7, 34.7, 0.1, 8.2, 5.5, 
  7.765425E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 27.7, 34.5, 0.2, 8.3, 5.7, 
  7.765434E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 26.8, 34.5, 0.1, 8.3, 6.1, 
  7.765443E8, -155.96777, 19.564444, 1231, "KEAUHOU BAY (EMBAYMENT)", , , , 26.7, 34.6, , 8.3, 5.9, 