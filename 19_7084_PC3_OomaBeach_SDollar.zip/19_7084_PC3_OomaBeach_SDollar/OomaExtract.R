# Ooma EIS appendix with water values
pdf_file <- "~/Dropbox/WestHawaiiWaterQuality/Data/19_7051_OomaBch_SDollar_EIS/PDR2 Appendix Ooma Marine Chemistry.pdf"

# pull in PDF using 'pdftools' pkg
text <- pdf_text(pdf_file)

w <- grep("TABLE 1.", text)

# ...grep found this on page 53 and 57, need to mine the page 
# - not coded yet, send to console
cat(text[w])


write.table(text, "~/Dropbox/WestHawaiiWaterQuality/Data/19_7051_OomaBch_SDollar_EIS/Original/Ooma_RStudio_pdftools_WriteTable1Nov032006.txt", sep="\t")