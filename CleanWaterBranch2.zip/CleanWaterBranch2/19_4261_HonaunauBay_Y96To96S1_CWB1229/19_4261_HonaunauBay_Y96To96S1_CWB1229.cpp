Dataset {
  Sequence {
    Float64 time;
    Float32 longitude;
    Float32 latitude;
    Int32 location_id;
    String location_name;
    Float32 number_concentration_of_enterococcus_in_sea_water;
    Float32 number_concentration_of_clostridium_perfringens_in_sea_water;
    Int32 sea_water_quality_alert;
    Float32 sea_water_temperature;
    Float32 sea_water_salinity;
    Float32 sea_water_turbidity;
    Float32 sea_water_ph_reported_on_total_scale;
    Float32 mass_concentration_of_oxygen_in_sea_water;
    Float32 fractional_saturation_of_oxygen_in_sea_water;
  } s;
} s;
---------------------------------------------
  s.time, s.longitude, s.latitude, s.location_id, s.location_name, s.number_concentration_of_enterococcus_in_sea_water, s.number_concentration_of_clostridium_perfringens_in_sea_water, s.sea_water_quality_alert, s.sea_water_temperature, s.sea_water_salinity, s.sea_water_turbidity, s.sea_water_ph_reported_on_total_scale, s.mass_concentration_of_oxygen_in_sea_water, s.fractional_saturation_of_oxygen_in_sea_water
  8.235483E8, -155.91722, 19.426111, 1229, "HONAUNAU BAY (EMBAYMENT)", 1.0, , 0, , 24.0, , , , 